import React from 'react';
import CustomCursor from './components/UI/CustomCursor';
import NoiseOverlay from './components/UI/NoiseOverlay';
import Navigation from './components/Layout/Navigation';
import Hero from './components/Sections/Hero';
import About from './components/Sections/About';
import Projects from './components/Sections/Projects';
import Testimonials from './components/Sections/Testimonials';
import Contact from './components/Sections/Contact';

const App: React.FC = () => {
  return (
    <main className="relative bg-ink-black min-h-screen text-ink-paper selection:bg-accent-red selection:text-white">
      {/* Global Effects */}
      <CustomCursor />
      <NoiseOverlay />
      
      {/* Layout Elements */}
      <Navigation />

      {/* Sections */}
      <Hero />
      <About />
      <Projects />
      <Testimonials />
      <Contact />
      
    </main>
  );
};

export default App;