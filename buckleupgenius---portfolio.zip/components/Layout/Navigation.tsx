import React from 'react';
import { motion } from 'framer-motion';

const Navigation: React.FC = () => {
  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ delay: 1, duration: 0.8 }}
      className="fixed top-0 left-0 right-0 z-40 p-6 md:p-8 flex justify-between items-center"
    >
      <a href="#" className="block" data-cursor="hover">
        {/* 
            TODO: LOGO TROUBLESHOOTING
            If the image below is broken:
            1. Ensure 'logoFinal.png' exists in the 'public/assets/' folder of your project root.
            2. If using a bundler (Vite/Webpack) and the assets folder is inside 'src', 
               you must import it at the top: `import logo from '../../assets/logoFinal.png'` 
               and set `src={logo}`.
            3. Try moving the file to the 'public' folder and use `src="/assets/logoFinal.png"`.
        */}
        <img 
            src="assets/logoFinal.png" 
            alt="BuckleUpGenius" 
            className="h-12 md:h-16 w-auto object-contain"
            onError={(e) => {
              // Fallback text if image fails to load
              e.currentTarget.style.display = 'none';
              e.currentTarget.nextElementSibling?.classList.remove('hidden');
            }}
        />
        <span className="hidden font-serif text-2xl font-black text-ink-black tracking-tighter">BUCKLE UP</span>
      </a>
      
      <div className="hidden md:flex gap-8 items-center">
        {['About', 'Projects', 'Contact'].map((item) => (
          <a 
            key={item} 
            href={`#${item.toLowerCase()}`} 
            className="text-ink-black font-sans text-sm uppercase tracking-[0.2em] font-bold hover:text-white transition-colors"
            data-cursor="hover"
          >
            {item}
          </a>
        ))}
      </div>

      <div className="md:hidden">
          {/* Mobile Menu Icon */}
          <div className="w-8 h-8 flex flex-col justify-center gap-1.5 items-end">
              <div className="w-8 h-1 bg-ink-black" />
              <div className="w-6 h-1 bg-ink-black" />
          </div>
      </div>
    </motion.nav>
  );
};

export default Navigation;