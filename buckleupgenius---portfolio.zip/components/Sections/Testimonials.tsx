import React from 'react';
import SectionWrapper from '../UI/SectionWrapper';
import { TESTIMONIALS } from '../../constants';
import { Quote } from 'lucide-react';

const Testimonials: React.FC = () => {
  return (
    <SectionWrapper id="testimonials" className="bg-neutral-900/30">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {TESTIMONIALS.map((t) => (
                <div key={t.id} className="bg-ink-charcoal p-8 md:p-12 border border-neutral-800 rounded-sm relative group hover:border-accent-violet/50 transition-colors duration-500">
                    <Quote className="text-accent-violet w-8 h-8 mb-6 opacity-50" />
                    <p className="font-serif text-xl md:text-2xl text-neutral-300 leading-relaxed mb-8">
                        "{t.text}"
                    </p>
                    <div className="mt-auto">
                        <p className="text-white font-medium tracking-wide">{t.name}</p>
                        <p className="text-neutral-500 text-sm mt-1">{t.role}</p>
                    </div>
                    {/* Corner accents */}
                    <div className="absolute top-0 right-0 w-4 h-4 border-t border-r border-neutral-700 opacity-0 group-hover:opacity-100 transition-opacity" />
                    <div className="absolute bottom-0 left-0 w-4 h-4 border-b border-l border-neutral-700 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
            ))}
        </div>
    </SectionWrapper>
  );
};

export default Testimonials;