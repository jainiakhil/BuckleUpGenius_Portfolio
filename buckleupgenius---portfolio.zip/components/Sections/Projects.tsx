import React, { useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import SectionWrapper from '../UI/SectionWrapper';
import { PROJECTS } from '../../constants';
import { Project } from '../../types';

// 3D Tilt Card Component
const ProjectCard: React.FC<{ project: Project; index: number }> = ({ project, index }) => {
  const ref = useRef<HTMLDivElement>(null);

  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseXSpring = useSpring(x);
  const mouseYSpring = useSpring(y);

  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["15deg", "-15deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-15deg", "15deg"]);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;
    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      style={{
        rotateX,
        rotateY,
        transformStyle: "preserve-3d",
      }}
      className="relative w-full aspect-[4/5] md:aspect-[3/4] group cursor-pointer"
      data-cursor="hover"
    >
      <div 
        style={{ transform: "translateZ(75px)", transformStyle: "preserve-3d" }}
        className="absolute inset-0 bg-neutral-900 rounded-sm overflow-hidden border border-neutral-800"
      >
        <img 
          src={project.image} 
          alt={project.title} 
          className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity duration-500 grayscale group-hover:grayscale-0"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-90" />
        
        <div className="absolute bottom-0 left-0 p-6 md:p-8 w-full transform translate-z-10">
            <span className="text-accent-red font-mono text-xs mb-2 block tracking-wider">{project.category} — {project.year}</span>
            <h3 className="font-serif text-3xl md:text-4xl text-ink-paper mb-2">{project.title}</h3>
            <p className="text-neutral-400 text-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 transform translate-y-4 group-hover:translate-y-0">
                {project.description}
            </p>
        </div>
      </div>
    </motion.div>
  );
};

const Projects: React.FC = () => {
  return (
    <SectionWrapper id="projects">
      <div className="mb-20 flex flex-col items-start">
        <h2 className="font-serif text-5xl md:text-7xl text-ink-paper">Selected Work</h2>
        <div className="h-1 w-24 bg-accent-red mt-4" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-24 perspective-1000">
        {PROJECTS.map((project, index) => (
          <div key={project.id} className={index % 2 !== 0 ? "md:mt-32" : ""}>
            <ProjectCard project={project} index={index} />
          </div>
        ))}
      </div>
      
      {/* View All Button */}
      <div className="mt-24 flex justify-center">
        <button 
            className="px-10 py-4 border border-neutral-700 rounded-full text-neutral-300 hover:bg-white hover:text-black transition-all duration-300 tracking-widest uppercase text-sm"
            data-cursor="hover"
        >
            View Full Archive
        </button>
      </div>
    </SectionWrapper>
  );
};

export default Projects;