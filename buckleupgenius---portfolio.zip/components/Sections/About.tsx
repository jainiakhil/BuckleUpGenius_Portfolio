import React, { useState, useEffect, useRef } from 'react';
import { motion, useInView, Variants } from 'framer-motion';
import SectionWrapper from '../UI/SectionWrapper';

// Typewriter Text Component
const TypewriterText: React.FC<{ text: string; delay?: number }> = ({ text, delay = 0 }) => {
  // Split into words for smoother wrapping than characters
  const words = text.split(" ");

  const container: Variants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.02, delayChildren: delay }
    }
  };

  const child: Variants = {
    hidden: { opacity: 0, y: 5 },
    visible: { opacity: 1, y: 0, transition: { type: "spring", damping: 12, stiffness: 200 } }
  };

  return (
    <motion.div variants={container} initial="hidden" whileInView="visible" viewport={{ once: true }} className="inline-block">
      {words.map((word, index) => (
        <motion.span key={index} variants={child} className="inline-block mr-1.5 mb-1 relative">
          {word}
        </motion.span>
      ))}
    </motion.div>
  );
};

const About: React.FC = () => {
  const [showComic, setShowComic] = useState(false);
  const containerRef = useRef(null);
  const isInView = useInView(containerRef, { once: true, amount: 0.3 });

  useEffect(() => {
    if (isInView) {
      const timer = setTimeout(() => {
        setShowComic(true);
      }, 2000); // 2 Second Delay before glitch
      return () => clearTimeout(timer);
    }
  }, [isInView]);

  return (
    <SectionWrapper id="about" className="bg-ink-charcoal relative">
      {/* Decorative skewed backdrop for the whole section */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-neutral-900/50 -skew-x-12 translate-x-32 z-0 pointer-events-none" />

      <div ref={containerRef} className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
        
        {/* --- LEFT SIDE: BIO PANEL --- */}
        <div className="order-2 lg:order-1">
          {/* Comic Panel Container */}
          <div className="relative bg-ink-paper border-4 border-ink-black p-8 md:p-12 shadow-[12px_12px_0px_#050505]">
            {/* Header Badge */}
            <div className="absolute -top-6 -left-6 bg-accent-red border-4 border-ink-black px-6 py-2 transform -rotate-2">
              <h2 className="font-sans font-black text-3xl md:text-4xl text-white tracking-widest uppercase">
                About Me
              </h2>
            </div>

            {/* Subheader */}
            <div className="mt-6 mb-8">
              <h3 className="font-serif text-2xl md:text-3xl text-ink-black font-bold">
                Astrophysicist. Engineer. <span className="text-accent-violet">Creator.</span>
              </h3>
              <div className="h-1.5 w-24 bg-comic-yellow mt-4 border-2 border-ink-black" />
            </div>

            {/* Bio Body */}
            <div className="font-sans text-lg md:text-xl text-ink-charcoal leading-relaxed space-y-6">
              <p>
                <TypewriterText 
                  delay={0.2}
                  text="I don’t just build; I calculate the physics of creativity. With a background in astrophysics and engineering, my work is grounded in precision but fueled by a writer’s soul and an artist’s eye." 
                />
              </p>
              <p>
                <TypewriterText 
                  delay={1.5}
                  text="From hundreds of successful design deployments to a vast archive of published technical and creative manuscripts, I’ve spent years mastering the intersection of logic and beauty." 
                />
              </p>
              <p className="font-bold text-ink-black">
                <TypewriterText 
                  delay={3.0}
                  text="I don't believe in 'good enough.' I believe in the relentless pursuit of the extraordinary. Whether you need a digital universe built from scratch or a story told through a lens, I am here to turn your vision into a reality that defies gravity." 
                />
              </p>
            </div>

            {/* Decorative corners */}
            <div className="absolute top-2 right-2 w-4 h-4 border-t-4 border-r-4 border-ink-black" />
            <div className="absolute bottom-2 left-2 w-4 h-4 border-b-4 border-l-4 border-ink-black" />
          </div>
        </div>

        {/* --- RIGHT SIDE: GLITCH IMAGE REVEAL --- */}
        <div className="order-1 lg:order-2 relative h-[500px] md:h-[700px] w-full flex items-center justify-center">
          
          {/* Image Frame */}
          <div className="relative w-full h-full max-w-md mx-auto">
            
            {/* UI Overlays (In front of images) */}
            <div className="absolute inset-0 z-20 pointer-events-none border-[6px] border-ink-black">
               {/* Halftone Shadow Overlay */}
               <div className="absolute inset-0 bg-halftone opacity-20 mix-blend-multiply" />
               
               {/* Action Speed Lines */}
               <div className="absolute top-10 -right-10 w-32 h-2 bg-comic-yellow border-2 border-black rotate-12" />
               <div className="absolute bottom-20 -left-10 w-48 h-3 bg-accent-red border-2 border-black -rotate-6" />
            </div>

            {/* REAL PHOTO (Background) - Shows initially */}
            <motion.div
              className="absolute inset-0 z-0 bg-neutral-800 overflow-hidden"
              animate={{ opacity: showComic ? 0 : 1 }}
              transition={{ duration: 0.1, delay: 0.1 }} // Instant cut after glitch starts
            >
               <img 
                 src="assets/OriginalFinal2.png" 
                 alt="Original Portrait" 
                 className="w-full h-full object-cover object-center grayscale contrast-125"
               />
            </motion.div>

            {/* COMIC PHOTO (Foreground) - Glitches in */}
            <motion.div
              className="absolute inset-0 z-10 bg-accent-violet overflow-hidden"
              initial={{ opacity: 0 }}
              animate={showComic ? { 
                opacity: [0, 1, 0, 1, 0, 1], // Flicker effect
                x: [-10, 10, -5, 5, 0],      // Horizontal shake
                scale: [1.1, 0.9, 1.05, 1],  // Scale distortion
                filter: ["hue-rotate(0deg)", "hue-rotate(90deg)", "hue-rotate(0deg)"] // Color shift
              } : { opacity: 0 }}
              transition={{ 
                duration: 0.4, 
                times: [0, 0.2, 0.4, 0.6, 0.8, 1],
                ease: "easeInOut"
              }}
            >
               <img 
                 src="assets/ComicFinal1.png" 
                 alt="Comic Portrait" 
                 className="w-full h-full object-cover object-center"
               />
               
               {/* Comic specific overlay effects */}
               <div className="absolute inset-0 bg-gradient-to-t from-accent-violet/50 to-transparent mix-blend-overlay" />
            </motion.div>

            {/* Floating Label Badge */}
            <motion.div 
                initial={{ scale: 0, rotate: -20 }}
                animate={{ scale: 1, rotate: 5 }}
                transition={{ delay: 2.5, type: "spring" }}
                className="absolute -bottom-6 -right-4 z-30 bg-white border-4 border-black px-4 py-2 shadow-[4px_4px_0px_#050505]"
            >
                <span className="font-mono font-bold text-sm tracking-widest text-ink-black">THE ORIGIN STORY</span>
            </motion.div>

          </div>
        </div>

      </div>
    </SectionWrapper>
  );
};

export default About;